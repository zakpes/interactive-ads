# scratch-card-with-canvas

scratch card sample, use native Canvas

## License

The MIT license.
